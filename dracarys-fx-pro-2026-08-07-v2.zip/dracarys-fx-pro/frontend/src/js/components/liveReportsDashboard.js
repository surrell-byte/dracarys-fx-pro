const REFRESH_MS = 60_000;
const page = document.querySelector("#page-live-reports");

if (page) {
    const status = page.querySelector("[data-live-status]");
    const summary = page.querySelector("[data-live-summary]");
    const insights = page.querySelector("[data-live-insights]");
    const trades = page.querySelector("[data-live-trades]");
    const signals = page.querySelector("[data-live-signals]");

    const load = async () => {
        try {
            const response = await fetch("/api/live-reports", { cache: "no-store" });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || "Unable to load live reports.");
            render(data);
            status.textContent = `Live · updated ${new Date(data.generatedAt || Date.now()).toLocaleTimeString()}`;
        } catch (error) {
            status.textContent = error.message || "Unable to load live reports.";
        }
    };

    function render(data) {
        const pct = (value, digits = 1) => Number.isFinite(value) ? Number(value).toFixed(digits) : "—";
        const signed = value => `${Number(value) >= 0 ? "+" : ""}${pct(value, 2)}%`;
        const trend = value => Number(value) >= 0 ? "edge-positive" : "edge-negative";
        summary.innerHTML = [
            ["Win rate", `${pct(data.winRate)}%`],
            ["Today's P/L", signed(data.totalPnlPct), trend(data.totalPnlPct)],
            ["Closed trades", data.totalTrades ?? 0],
            ["Open signals", data.openCount ?? 0],
            ["Profit factor", data.profitFactor === Infinity ? "∞" : pct(data.profitFactor, 2)]
        ].map(([label, value, className = ""]) => `<div class="metric"><div class="label">${label}</div><div class="value ${className}">${value}</div></div>`).join("");

        insights.innerHTML = (data.insights || []).map(item => `<li>${escapeHtml(item)}</li>`).join("") || "<li>No insights available yet.</li>";
        trades.innerHTML = table(data.allClosedTrades || [], true);
        signals.innerHTML = table(data.openHighConfidence || [], false);
    }

    function table(rows, closed) {
        if (!rows.length) return '<p class="muted">Nothing to show yet.</p>';
        return `<table class="live-reports-table"><thead><tr><th>Pair</th><th>Direction</th><th>Confidence</th><th>${closed ? "Result" : "Entry"}</th><th>${closed ? "P/L" : "Expires"}</th><th>Time</th></tr></thead><tbody>${rows.slice(0, 20).map(row => `<tr><td>${escapeHtml(row.symbol)}</td><td><span class="badge ${row.type === "BUY" ? "green" : "red"}">${escapeHtml(row.type)}</span></td><td>${escapeHtml(row.confidence ?? "—")}</td><td>${closed ? escapeHtml(row.outcome ?? "—") : escapeHtml(row.entry_price ?? "—")}</td><td class="${closed ? (Number(row.pnl_pct) >= 0 ? "edge-positive" : "edge-negative") : ""}">${closed ? `${Number(row.pnl_pct) >= 0 ? "+" : ""}${Number(row.pnl_pct ?? 0).toFixed(2)}%` : escapeHtml(row.expiry_label ?? "—")}</td><td>${formatTime(closed ? row.closed_at : row.created_at)}</td></tr>`).join("")}</tbody></table>`;
    }

    function formatTime(value) {
        const date = new Date(value);
        return Number.isNaN(date.valueOf()) ? "—" : date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }

    function escapeHtml(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
    }

    load();
    setInterval(load, REFRESH_MS);
}
