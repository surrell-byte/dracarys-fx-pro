# Live Reports upgrade

This project now exposes the scheduler’s structured data at `GET /api/latest`
on the GCP report server and displays it through the same-origin Vercel route
`/api/live-reports` every minute. The browser never receives the upstream
Basic Auth credentials.

## Deploy

1. On the GCP host, set `REPORTS_USER` and `REPORTS_PASSWORD` in
   `frontend/.env`, then run `setup-gcp-reports-server.sh` followed by
   `setup-gcp-https.sh`.
2. In Vercel, set `REPORTS_API_URL` to `https://YOUR_HOST/api/latest`, plus
   `REPORTS_API_USER` and `REPORTS_API_PASSWORD` to the matching values.
3. Deploy and open **Live Reports** in the sidebar.

Use `./upgrade-dashboard/verify.sh` before deployment.

`install.sh` verifies the integrated upgrade is complete. `rollback.sh` is
intentionally non-destructive: this source-level change should be reverted
through version control, while scheduler data remains untouched.
