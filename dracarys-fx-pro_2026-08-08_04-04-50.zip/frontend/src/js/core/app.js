import { UnifiedMarketDataService } from "@services/unifiedMarketDataService.js";
import { generateSignal, STRATEGIES } from "@signals/signalEngine.js";
import { StrategyTester } from "@analysis/strategyTester.js";
import { runBacktest } from "@analysis/backtestEngine.js";
import { BinaryOutcomeTracker } from "@analysis/binaryTracker.js";
import { getHigherTimeframeTrend } from "@analysis/multiTimeframe.js";
import demo from "@demo/demoAccount.js";
import { openPosition, closePosition } from "@demo/tradeEngine.js";
import { renderHistoryTable, clearHistory as clearDemoHistory } from "@demo/tradeHistory.js";
import { getStrategyLeaderboard } from "@demo/analytics.js";
import { renderJournal, clearJournal } from "@demo/journal.js";

const API_URL = "http://localhost:3001";
const HTF_REFRESH_MS = 15 * 60 * 1000; // daily candles barely move intraday

const state = {
    candles: [],
    history: [],
    symbol: "btcusdt",
    apiSymbol: "BTC/USDT",
    assetClass: "crypto",
    interval: "1m",
    strategy: "balanced",
    maxCandles: 320,
    lastTradeAt: 0,
    higherTrend: { trend: "NEUTRAL", ready: false },
    htfTimer: null,
    paper: {
        side: null,
        entry: null,
        quantity: 0,
        stopLoss: null,
        takeProfit: null,
        realizedPnl: 0,
        demoId: null // links the live paper position to its Demo Account trade record
    }
};

const elements = {
    status: document.querySelector("#status"),
    marketLabel: document.querySelector("#marketLabel"),
    pairSelect: document.querySelector("#pairSelect"),
    strategySelect: document.querySelector("#strategySelect"),
    signal: document.querySelector("#signal"),
    confidence: document.querySelector("#confidence"),
    probBuy: document.querySelector("#probBuy"),
    probWait: document.querySelector("#probWait"),
    probSell: document.querySelector("#probSell"),
    probBuyFill: document.querySelector("#probBuyFill"),
    probWaitFill: document.querySelector("#probWaitFill"),
    probSellFill: document.querySelector("#probSellFill"),
    price: document.querySelector("#price"),
    reason: document.querySelector("#reason"),
    candleCount: document.querySelector("#candleCount"),
    support: document.querySelector("#support"),
    resistance: document.querySelector("#resistance"),
    rsi: document.querySelector("#rsi"),
    adx: document.querySelector("#adx"),
    macd: document.querySelector("#macd"),
    pattern: document.querySelector("#pattern"),
    strategyName: document.querySelector("#strategyName"),
    quality: document.querySelector("#quality"),
    volatility: document.querySelector("#volatility"),
    volumeRatio: document.querySelector("#volumeRatio"),
    chart: document.querySelector("#chart"),
    autoTrade: document.querySelector("#autoTrade"),
    tradeSize: document.querySelector("#tradeSize"),
    maxLoss: document.querySelector("#maxLoss"),
    cooldown: document.querySelector("#cooldown"),
    minConfidence: document.querySelector("#minConfidence"),
    useRiskSizing: document.querySelector("#useRiskSizing"),
    accountSize: document.querySelector("#accountSize"),
    riskPercent: document.querySelector("#riskPercent"),
    htfTrend: document.querySelector("#htfTrend"),
    stopLoss: document.querySelector("#stopLoss"),
    takeProfit: document.querySelector("#takeProfit"),
    entryPrice: document.querySelector("#entryPrice"),
    takeProfit1: document.querySelector("#takeProfit1"),
    riskReward: document.querySelector("#riskReward"),
    executionStatus: document.querySelector("#executionStatus"),
    paperPosition: document.querySelector("#paperPosition"),
    paperEntry: document.querySelector("#paperEntry"),
    paperPnl: document.querySelector("#paperPnl"),
    paperStop: document.querySelector("#paperStop"),
    paperTarget: document.querySelector("#paperTarget"),
    historyList: document.querySelector("#historyList"),
    statSignalsCount: document.querySelector("#statSignalsCount"),
    statOpenTrades: document.querySelector("#statOpenTrades"),
    statAccountBalance: document.querySelector("#statAccountBalance"),
    statAccountBalanceSub: document.querySelector("#statAccountBalanceSub"),
    clearHistory: document.querySelector("#clearHistory"),
    testerBody: document.querySelector("#testerBody"),
    regimeBody: document.querySelector("#regimeBody"),
    sessionBody: document.querySelector("#sessionBody"),
    assetBody: document.querySelector("#assetBody"),
    binaryStatsBody: document.querySelector("#binaryStatsBody"),
    payoutRatioInput: document.querySelector("#payoutRatioInput"),
    testerReset: document.querySelector("#testerReset"),
    tradeNowBtn: document.querySelector("#tradeNowBtn"),
    closePaperBtn: document.querySelector("#closePaperBtn"),
    tradeResult: document.querySelector("#tradeResult"),
    tradeResultBody: document.querySelector("#tradeResultBody"),
    demoBalance: document.querySelector("#demoBalance"),
    demoEquity: document.querySelector("#demoEquity"),
    demoMarginUsed: document.querySelector("#demoMarginUsed"),
    demoFreeMargin: document.querySelector("#demoFreeMargin"),
    demoWinRate: document.querySelector("#demoWinRate"),
    demoTrades: document.querySelector("#demoTrades"),
    demoNetProfit: document.querySelector("#demoNetProfit"),
    demoResetBtn: document.querySelector("#demoResetBtn"),
    demoLeaderboardBody: document.querySelector("#demoLeaderboardBody"),
    demoHistoryList: document.querySelector("#demoHistoryList"),
    journalList: document.querySelector("#journalList"),
    clearJournalBtn: document.querySelector("#clearJournalBtn"),
    backtestSymbol: document.querySelector("#backtestSymbol"),
    backtestInterval: document.querySelector("#backtestInterval"),
    backtestStrategy: document.querySelector("#backtestStrategy"),
    backtestLookback: document.querySelector("#backtestLookback"),
    backtestPayout: document.querySelector("#backtestPayout"),
    backtestRunBtn: document.querySelector("#backtestRunBtn"),
    backtestStatus: document.querySelector("#backtestStatus"),
    backtestLeaderboardBody: document.querySelector("#backtestLeaderboardBody"),
    backtestBinaryBody: document.querySelector("#backtestBinaryBody")
};

const market = new UnifiedMarketDataService(state.symbol, state.interval, state.maxCandles, state.assetClass);
const ctx = elements.chart.getContext("2d");
const tester = new StrategyTester(Object.keys(STRATEGIES));
const binaryTracker = new BinaryOutcomeTracker(Object.keys(STRATEGIES));

market.onStatus((status) => {
    elements.status.textContent = status;
    elements.status.dataset.status = status.toLowerCase().replace(/\s+/g, "-");
});

market.onTick((candle) => {
    updatePrice(candle.close);
    checkPaperStops(candle.close);
    renderPaperAccount(candle.close);
    demo.markToMarket({ [state.symbol]: candle.close });
    renderDemoAccount();
});

market.onCandle((candle) => {
    upsertCandle(candle);
    const signal = generateSignal(state.candles, state.strategy, signalContext());
    renderSignal(signal);
    drawChart();
    recordSignal(signal);
    maybeExecute(signal);
    tester.onCandle(state.candles);
    renderTester();
    binaryTracker.onCandle(state.candles);
    renderBinaryStats();
});

function signalContext() {
    return { higherTrend: state.higherTrend.trend };
}

elements.autoTrade.addEventListener("change", () => {
    setExecutionStatus(elements.autoTrade.checked ? "Auto mode armed" : "Manual mode");
});

elements.pairSelect.addEventListener("change", () => {
    loadSelectedMarket();
});

elements.strategySelect.addEventListener("change", () => {
    state.strategy = elements.strategySelect.value;
    const signal = generateSignal(state.candles, state.strategy, signalContext());
    renderSignal(signal);
    recordSignal(signal);
    setExecutionStatus(`${STRATEGIES[state.strategy]?.label ?? "Strategy"} active`);
});

elements.clearHistory.addEventListener("click", () => {
    state.history = [];
    renderHistory();
    clearDemoHistory();
    renderDemoAccount();
});

elements.testerReset?.addEventListener("click", () => {
    tester.reset();
    renderTester();
    binaryTracker.reset();
    renderBinaryStats();
});

elements.payoutRatioInput?.addEventListener("change", () => {
    renderBinaryStats();
});

elements.backtestRunBtn?.addEventListener("click", () => {
    runBacktestFromUi();
});

elements.demoResetBtn?.addEventListener("click", () => {
    const confirmed = window.confirm("Reset the Demo Account back to $10,000? This clears balance, trade history, and the journal.");
    if (!confirmed) return;
    demo.reset();
    state.paper.demoId = null;
    renderDemoAccount();
});

elements.clearJournalBtn?.addEventListener("click", () => {
    clearJournal();
    renderJournal(elements.journalList);
});

elements.tradeNowBtn?.addEventListener("click", async () => {
    const signal = generateSignal(state.candles, state.strategy, signalContext());
    if (!signal.ready) {
        setExecutionStatus("Not enough candles yet");
        return;
    }
    if (signal.type === "HOLD") {
        setExecutionStatus("Signal is HOLD — no trade placed");
        showTradeResult({ status: "skipped", reason: "Signal is HOLD" });
        return;
    }
    await executeManualTrade(signal);
});

elements.closePaperBtn?.addEventListener("click", () => {
    const price = state.candles.at(-1)?.close;
    if (!state.paper.side) {
        setExecutionStatus("No open position to close");
        return;
    }
    const pnl = calculatePositionPnl(price);
    state.paper.realizedPnl += pnl;
    const closedSide = state.paper.side;
    if (state.paper.demoId) {
        closePosition(state.paper.demoId, price, "Manually closed");
        state.paper.demoId = null;
    }
    state.paper.side = null;
    state.paper.entry = null;
    state.paper.quantity = 0;
    state.paper.stopLoss = null;
    state.paper.takeProfit = null;
    renderPaperAccount(price);
    renderDemoAccount();
    const msg = `Closed ${closedSide} — P/L: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}`;
    setExecutionStatus(msg);
    showTradeResult({ status: "closed", reason: msg });
    appendAction({ type: "CLOSE", confidence: 0, price, action: msg });
});

async function init() {
    updateMarketFromSelection();
    await loadMarket();
    await refreshHigherTimeframeTrend();
    startHtfRefreshTimer();
}

async function loadSelectedMarket() {
    elements.autoTrade.checked = false;
    updateMarketFromSelection();
    resetPaperAccount();
    await loadMarket();
    await refreshHigherTimeframeTrend();
    setExecutionStatus("Market switched, auto disabled");
}

function startHtfRefreshTimer() {
    window.clearInterval(state.htfTimer);
    state.htfTimer = window.setInterval(refreshHigherTimeframeTrend, HTF_REFRESH_MS);
}

async function refreshHigherTimeframeTrend() {
    state.higherTrend = await getHigherTimeframeTrend(state.apiSymbol, state.assetClass);
    renderHtfTrend();

    // Re-render the current signal so HTF-gated strategies pick up the fresh
    // bias immediately instead of waiting for the next closed candle.
    if (state.candles.length) {
        renderSignal(generateSignal(state.candles, state.strategy, signalContext()));
    }
}

function renderHtfTrend() {
    if (!elements.htfTrend) return;
    const { trend, ready } = state.higherTrend;
    elements.htfTrend.textContent = ready ? trend : "Loading";
    elements.htfTrend.dataset.trend = trend.toLowerCase();
}

async function loadMarket() {
    try {
        market.disconnect();
        elements.status.textContent = "Loading candles";
        state.candles = [];
        drawChart();
        market.setMarket(state.symbol, state.interval, state.assetClass);
        tester.setSymbol(state.apiSymbol);
        renderTester();
        binaryTracker.setSymbol(state.apiSymbol);
        renderBinaryStats();
        state.candles = await market.getCandles(state.symbol, state.interval, state.maxCandles, state.assetClass);
        renderSignal(generateSignal(state.candles, state.strategy, signalContext()));
        drawChart();
        renderPaperAccount(state.candles.at(-1)?.close);
        market.connect();
    } catch (error) {
        elements.status.textContent = "Data error";
        elements.reason.textContent = error.message;
    }
}

function updateMarketFromSelection() {
    const selectedPair = elements.pairSelect.selectedOptions[0];
    state.symbol = elements.pairSelect.value;
    state.apiSymbol = selectedPair?.dataset.apiSymbol ?? state.symbol.toUpperCase();
    state.assetClass = selectedPair?.dataset.assetClass ?? "crypto";
    state.strategy = elements.strategySelect.value;
    elements.marketLabel.textContent = `${state.symbol.toUpperCase()} · ${state.interval} live candles`;
}

function upsertCandle(candle) {
    const last = state.candles.at(-1);

    if (last?.time === candle.time) {
        state.candles[state.candles.length - 1] = candle;
    } else {
        state.candles.push(candle);
    }

    state.candles = state.candles.slice(-state.maxCandles);
}

// Probability Engine display: buy/wait/sell always sum to 100% by
// construction (see ai/probabilityEngine.js), so this just renders
// whatever three numbers came back - no additional math here.
function renderProbabilityBreakdown(probabilities) {
    const { buyProbability = 0, waitProbability = 1, sellProbability = 0 } = probabilities ?? {};
    const buyPct = Math.round(buyProbability * 100);
    const waitPct = Math.round(waitProbability * 100);
    const sellPct = Math.round(sellProbability * 100);

    if (elements.probBuy) elements.probBuy.textContent = `${buyPct}%`;
    if (elements.probWait) elements.probWait.textContent = `${waitPct}%`;
    if (elements.probSell) elements.probSell.textContent = `${sellPct}%`;

    if (elements.probBuyFill) elements.probBuyFill.style.width = `${buyPct}%`;
    if (elements.probWaitFill) elements.probWaitFill.style.width = `${waitPct}%`;
    if (elements.probSellFill) elements.probSellFill.style.width = `${sellPct}%`;
}

function renderSignal(signal) {
    elements.signal.textContent = signal.type;
    elements.signal.dataset.signal = signal.type.toLowerCase();
    elements.confidence.textContent = `${signal.confidence ?? 0}%`;
    document.documentElement.style.setProperty("--confidence-fill", `${signal.confidence ?? 0}%`);
    elements.reason.textContent = signal.reason;
    elements.candleCount.textContent = String(state.candles.length);
    updatePrice(signal.price);

    renderProbabilityBreakdown(signal.probabilities);

    elements.support.textContent = formatPrice(signal.support);
    elements.resistance.textContent = formatPrice(signal.resistance);
    elements.rsi.textContent = formatNumber(signal.indicators?.rsi);
    elements.adx.textContent = formatNumber(signal.indicators?.adx);
    elements.macd.textContent = formatNumber(signal.indicators?.macd, 4);
    elements.pattern.textContent = signal.indicators?.pattern ?? "none";
    elements.strategyName.textContent = signal.strategy ?? STRATEGIES[state.strategy]?.label ?? "Balanced";
    elements.quality.textContent = signal.quality ?? "--";
    elements.quality.dataset.quality = (signal.quality ?? "low").toLowerCase();
    elements.volatility.textContent = Number.isFinite(signal.indicators?.atrPercent)
        ? `${formatNumber(signal.indicators.atrPercent, 2)}%`
        : "--";
    elements.volumeRatio.textContent = Number.isFinite(signal.indicators?.volumeRatio)
        ? `${formatNumber(signal.indicators.volumeRatio, 2)}x`
        : "--";

    if (elements.entryPrice) {
        elements.entryPrice.textContent = signal.risk ? formatPrice(signal.risk.entry) : "--";
    }
    if (elements.stopLoss) {
        elements.stopLoss.textContent = signal.risk ? formatPrice(signal.risk.stopLoss) : "--";
    }
    if (elements.takeProfit1) {
        elements.takeProfit1.textContent = signal.risk ? formatPrice(signal.risk.takeProfit1) : "--";
    }
    if (elements.takeProfit) {
        elements.takeProfit.textContent = signal.risk ? formatPrice(signal.risk.takeProfit2) : "--";
    }
    if (elements.riskReward) {
        elements.riskReward.textContent = signal.risk ? signal.risk.rrLabel : "--";
    }

    renderDecisionChecklist(signal);
}

// Item 15 (Decision Checklist): a plain-language readout of what the signal
// engine is actually seeing, driven by the same indicators it scores on —
// not a separate calculation, so it can't drift out of sync with the signal.
function renderDecisionChecklist(signal) {
    const container = document.querySelector("#decisionChecklist");
    if (!container) return;

    const indicators = signal.indicators ?? {};
    const items = [];

    if (indicators.higherTrend) {
        const trend = indicators.higherTrend;
        items.push({
            status: trend === "UP" ? "ok" : trend === "DOWN" ? "bad" : "warn",
            icon: trend === "UP" ? "✓" : trend === "DOWN" ? "✕" : "⚠",
            text: `Daily Trend: ${trend}`
        });
    } else {
        items.push({ status: "neutral", icon: "•", text: "Daily Trend — not used by this strategy" });
    }

    if (Number.isFinite(indicators.ema20) && Number.isFinite(indicators.ema50)) {
        const bullish = indicators.ema20 > indicators.ema50;
        items.push({
            status: bullish ? "ok" : "bad",
            icon: bullish ? "✓" : "✕",
            text: `EMA20 ${bullish ? ">" : "<"} EMA50`
        });
    } else {
        items.push({ status: "neutral", icon: "•", text: "EMA20 / EMA50 — collecting candles" });
    }

    if (Number.isFinite(indicators.volumeRatio)) {
        const ratio = indicators.volumeRatio;
        const status = ratio >= 1.15 ? "ok" : ratio < 0.75 ? "bad" : "warn";
        items.push({
            status,
            icon: status === "ok" ? "✓" : status === "bad" ? "✕" : "⚠",
            text: `Volume ${formatNumber(ratio, 2)}x average`
        });
    } else {
        items.push({ status: "neutral", icon: "•", text: "Volume — collecting candles" });
    }

    if (Number.isFinite(indicators.adx)) {
        const adx = indicators.adx;
        const status = adx >= 25 ? "ok" : adx < 18 ? "bad" : "warn";
        items.push({
            status,
            icon: status === "ok" ? "✓" : status === "bad" ? "✕" : "⚠",
            text: `ADX ${formatNumber(adx, 1)} ${adx >= 25 ? "above" : "below"} 25`
        });
    } else {
        items.push({ status: "neutral", icon: "•", text: "ADX — collecting candles" });
    }

    if (Number.isFinite(indicators.rsi)) {
        const rsi = indicators.rsi;
        let status = "ok";
        let label = `RSI neutral (${formatNumber(rsi, 1)})`;
        if (rsi >= 65) {
            status = "warn";
            label = `RSI near overbought (${formatNumber(rsi, 1)})`;
        } else if (rsi <= 35) {
            status = "warn";
            label = `RSI near oversold (${formatNumber(rsi, 1)})`;
        }
        items.push({ status, icon: status === "ok" ? "✓" : "⚠", text: label });
    } else {
        items.push({ status: "neutral", icon: "•", text: "RSI — collecting candles" });
    }

    container.innerHTML = items.map(item => `
        <div class="check ${item.status}">
            <span class="check-icon">${item.icon}</span>
            <span>${item.text}</span>
        </div>
    `).join("");
}

function updatePrice(price) {
    elements.price.textContent = formatPrice(price);
}

function recordSignal(signal) {
    state.history.unshift({
        time: new Date(),
        type: signal.type,
        confidence: signal.confidence,
        price: signal.price,
        reason: signal.reason,
        action: signal.strategy
    });

    state.history = state.history.slice(0, 30);
    renderHistory();
}

async function maybeExecute(signal) {
    const settings = getTradeSettings();

    if (!settings.autoTrade) {
        setExecutionStatus("Manual mode");
        return;
    }

    if (!signal.ready || signal.type === "HOLD") {
        setExecutionStatus("Waiting for actionable signal");
        return;
    }

    if (signal.confidence < settings.minConfidence) {
        setExecutionStatus(`Confidence below ${settings.minConfidence}%`);
        return;
    }

    if (isCoolingDown(settings.cooldownSeconds)) {
        setExecutionStatus("Cooldown active");
        return;
    }

    const pnl = getPaperPnl(signal.price);
    if (pnl <= -settings.maxLoss) {
        elements.autoTrade.checked = false;
        setExecutionStatus("Max loss reached, auto disabled");
        return;
    }

    state.lastTradeAt = Date.now();

    if (settings.mode === "paper") {
        const result = executePaperTrade(signal, resolveQuantity(signal, settings));
        appendAction(result);
        setExecutionStatus(result.action);
        return;
    }

    try {
        setExecutionStatus("Sending order request");
        const result = await sendTrade(signal, settings, resolveQuantity(signal, settings));
        appendAction({
            type: signal.type,
            price: signal.price,
            confidence: signal.confidence,
            action: `${result.status}: ${result.reason ?? result.side ?? "order response"}`
        });
        setExecutionStatus(result.status);
    } catch (error) {
        appendAction({
            type: signal.type,
            price: signal.price,
            confidence: signal.confidence,
            action: `Error: ${error.message}`
        });
        setExecutionStatus("Trade request failed");
    }
}

async function executeManualTrade(signal) {
    const settings = getTradeSettings();

    elements.tradeNowBtn.disabled = true;
    elements.tradeNowBtn.textContent = "Placing...";

    try {
        const quantity = resolveQuantity(signal, settings);

        if (settings.mode === "paper") {
            const result = executePaperTrade(signal, quantity);
            state.lastTradeAt = Date.now();
            appendAction(result);
            setExecutionStatus(`Manual: ${result.action}`);
            showTradeResult({
                status: "paper",
                side: signal.type.toLowerCase(),
                price: signal.price,
                reason: result.action,
                quantity,
                stopLoss: signal.risk?.stopLoss,
                takeProfit: signal.risk?.takeProfit
            });
        } else {
            setExecutionStatus("Sending manual order");
            const result = await sendTrade(signal, settings, quantity);
            state.lastTradeAt = Date.now();
            appendAction({
                type: signal.type,
                price: signal.price,
                confidence: signal.confidence,
                action: `Manual ${result.status}: ${result.reason ?? result.side ?? "ok"}`
            });
            setExecutionStatus(`Manual: ${result.status}`);
            showTradeResult(result);
        }
    } catch (error) {
        setExecutionStatus(`Manual trade error: ${error.message}`);
        showTradeResult({ status: "error", reason: error.message });
    } finally {
        elements.tradeNowBtn.disabled = false;
        elements.tradeNowBtn.textContent = "Trade Now";
    }
}

function showTradeResult(result) {
    if (!elements.tradeResult || !elements.tradeResultBody) return;
    const statusClass = result.status === "error" ? "tr-error"
        : result.status === "skipped" ? "tr-skip"
        : result.status === "blocked" ? "tr-skip"
        : result.status === "closed" ? "tr-close"
        : result.side === "buy" || result.status === "paper" ? "tr-buy"
        : "tr-sell";
    elements.tradeResultBody.innerHTML = `
        <span class="tr-badge ${statusClass}">${(result.status ?? "—").toUpperCase()}</span>
        ${result.side ? `<span class="tr-side">${result.side.toUpperCase()}</span>` : ""}
        ${result.price ? `<span class="tr-price">${formatPrice(result.price)}</span>` : ""}
        ${result.quantity ? `<span class="tr-qty">Qty ${result.quantity}</span>` : ""}
        ${Number.isFinite(result.stopLoss) ? `<span class="tr-stop">SL ${formatPrice(result.stopLoss)}</span>` : ""}
        ${Number.isFinite(result.takeProfit) ? `<span class="tr-target">TP ${formatPrice(result.takeProfit)}</span>` : ""}
        <span class="tr-reason">${result.reason ?? ""}</span>
    `;
    elements.tradeResult.hidden = false;
}

function getTradeSettings() {
    const checkedMode = document.querySelector("input[name='tradeMode']:checked");

    return {
        autoTrade: elements.autoTrade.checked,
        mode: checkedMode?.value ?? "dry-run",
        quantity: Math.max(Number(elements.tradeSize.value) || 0, 0),
        maxLoss: Math.max(Number(elements.maxLoss.value) || 0, 0),
        cooldownSeconds: Math.max(Number(elements.cooldown.value) || 0, 0),
        minConfidence: Math.min(Math.max(Number(elements.minConfidence.value) || 1, 1), 100),
        useRiskSizing: Boolean(elements.useRiskSizing?.checked),
        accountSize: Math.max(Number(elements.accountSize?.value) || 0, 0),
        riskPercent: Math.min(Math.max(Number(elements.riskPercent?.value) || 0, 0), 100)
    };
}

// Module 8 (Position Sizing): risk% of account / ATR stop distance. Falls
// back to the fixed trade-size field whenever risk sizing is off or the
// signal has no ATR-based stop distance to size against yet.
function resolveQuantity(signal, settings) {
    if (!settings.useRiskSizing) return settings.quantity;

    const stopDistance = signal.risk?.stopDistance;
    if (!Number.isFinite(stopDistance) || stopDistance <= 0) return settings.quantity;

    const riskAmount = settings.accountSize * (settings.riskPercent / 100);
    if (!Number.isFinite(riskAmount) || riskAmount <= 0) return settings.quantity;

    const sized = riskAmount / stopDistance;
    return Number.isFinite(sized) && sized > 0 ? Number(sized.toFixed(6)) : settings.quantity;
}

function isCoolingDown(cooldownSeconds) {
    return Date.now() - state.lastTradeAt < cooldownSeconds * 1000;
}

function executePaperTrade(signal, quantity) {
    const price = signal.price;
    const nextSide = signal.type === "BUY" ? "long" : "short";
    const previousSide = state.paper.side;
    let action = "Paper hold";

    if (previousSide && previousSide !== nextSide) {
        state.paper.realizedPnl += calculatePositionPnl(price);
        if (state.paper.demoId) {
            closePosition(state.paper.demoId, price, `Flipped ${previousSide} \u2192 ${nextSide}`);
        }
        state.paper.side = null;
        state.paper.entry = null;
        state.paper.quantity = 0;
        state.paper.stopLoss = null;
        state.paper.takeProfit = null;
        state.paper.demoId = null;
        action = `Paper closed ${previousSide}`;
    }

    if (state.paper.side !== nextSide) {
        state.paper.side = nextSide;
        state.paper.entry = price;
        state.paper.quantity = quantity;
        state.paper.stopLoss = signal.risk?.stopLoss ?? null;
        state.paper.takeProfit = signal.risk?.takeProfit ?? null;
        const opened = openPosition({
            symbol: state.symbol,
            strategy: STRATEGIES[state.strategy]?.label ?? state.strategy,
            side: nextSide,
            entryPrice: price,
            quantity,
            stopLoss: state.paper.stopLoss,
            takeProfit: state.paper.takeProfit,
            confidence: signal.confidence,
            reason: signal.reason
        });
        state.paper.demoId = opened?.id ?? null;
        action = `${action}; opened ${nextSide}`;
    }

    renderPaperAccount(price);
    renderDemoAccount();

    return {
        type: signal.type,
        confidence: signal.confidence,
        price,
        quantity,
        stopLoss: state.paper.stopLoss,
        takeProfit: state.paper.takeProfit,
        action
    };
}

// Module 7 in action: the paper account enforces the ATR stop-loss and
// R-multiple take-profit automatically on every tick, so the risk levels
// shown in the signal panel aren't just informational for paper mode.
function checkPaperStops(markPrice) {
    const { side, stopLoss, takeProfit } = state.paper;
    if (!side || !Number.isFinite(markPrice)) return;
    if (!Number.isFinite(stopLoss) && !Number.isFinite(takeProfit)) return;

    const hitStop = Number.isFinite(stopLoss) && (
        side === "long" ? markPrice <= stopLoss : markPrice >= stopLoss
    );
    const hitTarget = Number.isFinite(takeProfit) && (
        side === "long" ? markPrice >= takeProfit : markPrice <= takeProfit
    );

    if (!hitStop && !hitTarget) return;

    const pnl = calculatePositionPnl(markPrice);
    state.paper.realizedPnl += pnl;
    const closedSide = side;
    const label = hitStop ? "Stop-loss hit" : "Take-profit hit";
    if (state.paper.demoId) {
        closePosition(state.paper.demoId, markPrice, label);
        state.paper.demoId = null;
    }
    state.paper.side = null;
    state.paper.entry = null;
    state.paper.quantity = 0;
    state.paper.stopLoss = null;
    state.paper.takeProfit = null;
    renderPaperAccount(markPrice);
    renderDemoAccount();

    const msg = `${label} on ${closedSide} — P/L: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}`;
    setExecutionStatus(msg);
    showTradeResult({ status: "closed", reason: msg, price: markPrice });
    appendAction({ type: "CLOSE", confidence: 0, price: markPrice, action: msg });
}

function resetPaperAccount() {
    if (state.paper.demoId) {
        const lastPrice = state.candles.at(-1)?.close ?? state.paper.entry;
        if (Number.isFinite(lastPrice)) {
            closePosition(state.paper.demoId, lastPrice, "Market switched");
        }
    }
    state.paper = {
        side: null,
        entry: null,
        quantity: 0,
        stopLoss: null,
        takeProfit: null,
        realizedPnl: 0,
        demoId: null
    };
    state.lastTradeAt = 0;
    renderPaperAccount();
    renderDemoAccount();
}

async function sendTrade(signal, settings, quantity = settings.quantity) {
    const response = await fetch(`${API_URL}/trade`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            signal,
            symbol: state.apiSymbol,
            quantity,
            mode: settings.mode,
            stopLoss: signal.risk?.stopLoss ?? null,
            takeProfit: signal.risk?.takeProfit ?? null
        })
    });

    if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
    }

    return response.json();
}

function appendAction(item) {
    state.history.unshift({
        time: new Date(),
        type: item.type,
        confidence: item.confidence,
        price: item.price,
        reason: item.action,
        action: "Trade"
    });

    state.history = state.history.slice(0, 30);
    renderHistory();
}

function renderTester() {
    if (!elements.testerBody || !elements.regimeBody || !elements.sessionBody || !elements.assetBody) return;

    const leaderboard = tester.getLeaderboard();
    elements.testerBody.innerHTML = leaderboard.length
        ? leaderboard.map(row => `
            <tr>
                <td>${row.label}</td>
                <td>${row.trades}</td>
                <td>${formatNumber(row.winRate, 1)}%</td>
                <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}%</td>
                <td>${formatSigned(row.avgPnl)}%</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5" class="empty-history">No closed trades yet</td></tr>`;

    const regimes = tester.getRegimeBreakdown();
    elements.regimeBody.innerHTML = regimes.length
        ? regimes.map(row => `
            <tr>
                <td>${row.label}</td>
                <td>${row.regime}</td>
                <td>${row.trades}</td>
                <td>${formatNumber(row.winRate, 1)}%</td>
                <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}%</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5" class="empty-history">No closed trades yet</td></tr>`;

    const sessions = tester.getSessionBreakdown();
    elements.sessionBody.innerHTML = sessions.length
        ? sessions.map(row => `
            <tr>
                <td>${row.label}</td>
                <td>${row.session}</td>
                <td>${row.trades}</td>
                <td>${formatNumber(row.winRate, 1)}%</td>
                <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}%</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5" class="empty-history">No closed trades yet</td></tr>`;

    const assets = tester.getAssetBreakdown();
    elements.assetBody.innerHTML = assets.length
        ? assets.map(row => `
            <tr>
                <td>${row.symbol}</td>
                <td>${row.trades}</td>
                <td>${formatNumber(row.winRate, 1)}%</td>
                <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}%</td>
                <td>${formatSigned(row.avgPnl)}%</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5" class="empty-history">No closed trades yet</td></tr>`;
}

// Milestone: binary-mode outcome tracking. Every number here comes from a
// real resolved bet (a real entry price compared against a real exit price
// N candles later) - buckets under the tracker's minimum sample size show
// "not enough data" instead of a percentage, rather than displaying a
// number that looks calibrated when it isn't.
function intervalToMinutes(interval) {
    const match = /^(\d+)([mhd])$/.exec(interval ?? "");
    if (!match) return null;
    const value = Number(match[1]);
    const unit = match[2];
    if (unit === "m") return value;
    if (unit === "h") return value * 60;
    if (unit === "d") return value * 60 * 24;
    return null;
}

function expiryLabel(expiryLength) {
    const minutesPerCandle = intervalToMinutes(state.interval);
    if (!Number.isFinite(minutesPerCandle)) return `${expiryLength} candles`;
    const totalMinutes = expiryLength * minutesPerCandle;
    const timeLabel = totalMinutes >= 60
        ? `${(totalMinutes / 60).toFixed(totalMinutes % 60 === 0 ? 0 : 1)}h`
        : `${totalMinutes}m`;
    return `${expiryLength} candles (~${timeLabel})`;
}

function renderBinaryStats() {
    if (!elements.binaryStatsBody) return;

    const payoutRatio = clampPayoutRatio(elements.payoutRatioInput?.value);
    const stats = binaryTracker.getBinaryStats(undefined, payoutRatio);
    elements.binaryStatsBody.innerHTML = stats.length
        ? stats.map(row => `
            <tr>
                <td>${row.label}</td>
                <td>${expiryLabel(row.expiryLength)}</td>
                <td>${row.trades}</td>
                <td>${row.reliable
                    ? `${formatNumber(row.winRate, 1)}%`
                    : `<span class="empty-history">not enough data (${row.trades}/${row.minSampleSize})</span>`}</td>
                <td>${formatNumber(row.breakevenWinRate, 1)}%</td>
                <td>${row.reliable ? `<span class="${edgeClass(row.edge)}">${formatSigned(row.edge)}%</span>` : "--"}</td>
                <td><span class="badge ${verdictClass(row.verdict)}">${row.verdict}</span></td>
            </tr>
        `).join("")
        : `<tr><td colspan="7" class="empty-history">No resolved binary trades yet</td></tr>`;
}

// Payout ratios outside (0, 1] aren't a real broker payout - fall back to
// the 85% default rather than feeding a nonsense number into the edge math.
function clampPayoutRatio(rawValue) {
    const value = Number(rawValue);
    if (!Number.isFinite(value) || value <= 0 || value > 1) return 0.85;
    return value;
}

function edgeClass(edge) {
    if (!Number.isFinite(edge)) return "";
    return edge > 0 ? "edge-positive" : "edge-negative";
}

function verdictClass(verdict) {
    if (!verdict) return "";
    if (verdict.startsWith("Edge detected")) return "verdict-edge";
    if (verdict.startsWith("No edge")) return "verdict-none";
    return "verdict-inconclusive";
}

// Historical backtest: fetches paginated real history, then replays it
// walk-forward through generateSignal() with no lookahead. Fully separate
// from `market`/`tester`/`binaryTracker` above - it never touches live
// streaming state or the live Strategy Lab's persisted trades.
let backtestRunning = false;

async function runBacktestFromUi() {
    if (backtestRunning || !elements.backtestRunBtn) return;

    const symbol = elements.backtestSymbol?.value ?? "btcusdt";
    const backtestAssetClass = elements.backtestSymbol?.selectedOptions[0]?.dataset.assetClass ?? "crypto";
    const interval = elements.backtestInterval?.value ?? "1m";
    const strategyChoice = elements.backtestStrategy?.value ?? "all";
    const strategyIds = strategyChoice === "all" ? Object.keys(STRATEGIES) : [strategyChoice];
    const total = Number(elements.backtestLookback?.value ?? 1000);
    const payoutRatio = clampPayoutRatio(elements.backtestPayout?.value);

    backtestRunning = true;
    elements.backtestRunBtn.disabled = true;
    elements.backtestRunBtn.textContent = "Fetching...";
    setBacktestStatus(`Fetching ${total.toLocaleString()} historical ${interval} candles for ${symbol.toUpperCase()}...`);

    try {
        const candles = await market.getHistoricalCandles(symbol, interval, { total }, backtestAssetClass);

        if (!candles.length) {
            setBacktestStatus("No historical candles came back for that pair/interval — try a different one.");
            return;
        }

        elements.backtestRunBtn.textContent = "Running...";
        const result = await runBacktest(candles, {
            strategyIds,
            payoutRatio,
            onProgress: (done, runTotal) => {
                setBacktestStatus(`Replaying candle ${done.toLocaleString()} / ${runTotal.toLocaleString()}...`);
            }
        });

        renderBacktestResults(result, interval);

        const from = new Date(result.meta.from).toLocaleString();
        const to = new Date(result.meta.to).toLocaleString();
        setBacktestStatus(
            `Done — ${result.meta.candleCount.toLocaleString()} candles (${from} → ${to}), `
            + `${result.meta.spotTrades} spot trades, ${result.meta.binaryTradesResolved} binary bets resolved`
            + (result.meta.binaryTradesDropped ? `, ${result.meta.binaryTradesDropped} still pending past the last candle` : "")
            + "."
        );
    } catch (error) {
        setBacktestStatus(`Backtest failed: ${error.message}`);
    } finally {
        backtestRunning = false;
        elements.backtestRunBtn.disabled = false;
        elements.backtestRunBtn.textContent = "Run Backtest";
    }
}

function setBacktestStatus(message) {
    if (elements.backtestStatus) elements.backtestStatus.textContent = message;
}

function renderBacktestResults(result, interval) {
    if (elements.backtestLeaderboardBody) {
        elements.backtestLeaderboardBody.innerHTML = result.spotLeaderboard.length
            ? result.spotLeaderboard.map(row => `
                <tr>
                    <td>${row.label}</td>
                    <td>${row.trades}</td>
                    <td>${formatNumber(row.winRate, 1)}%</td>
                    <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}%</td>
                    <td>${formatSigned(row.avgPnl)}%</td>
                    <td>${formatNumber(row.maxDrawdown, 1)}%</td>
                </tr>
            `).join("")
            : `<tr><td colspan="6" class="empty-history">No trades in this window</td></tr>`;
    }

    if (elements.backtestBinaryBody) {
        elements.backtestBinaryBody.innerHTML = result.binaryStats.length
            ? result.binaryStats.map(row => `
                <tr>
                    <td>${row.label}</td>
                    <td>${backtestExpiryLabel(row.expiryLength, interval)}</td>
                    <td>${row.trades}</td>
                    <td>${row.reliable
                        ? `${formatNumber(row.winRate, 1)}%`
                        : `<span class="empty-history">not enough data (${row.trades}/20)</span>`}</td>
                    <td>${formatNumber(row.breakevenWinRate, 1)}%</td>
                    <td>${row.reliable ? `<span class="${edgeClass(row.edge)}">${formatSigned(row.edge)}%</span>` : "--"}</td>
                    <td><span class="badge ${verdictClass(row.verdict)}">${row.verdict}</span></td>
                </tr>
            `).join("")
            : `<tr><td colspan="7" class="empty-history">No resolved binary bets in this window</td></tr>`;
    }
}

function backtestExpiryLabel(expiryLength, interval) {
    const minutesPerCandle = intervalToMinutes(interval);
    if (!Number.isFinite(minutesPerCandle)) return `${expiryLength} candles`;
    const totalMinutes = expiryLength * minutesPerCandle;
    const timeLabel = totalMinutes >= 60
        ? `${(totalMinutes / 60).toFixed(totalMinutes % 60 === 0 ? 0 : 1)}h`
        : `${totalMinutes}m`;
    return `${expiryLength} candles (~${timeLabel})`;
}

function formatSigned(value) {
    if (!Number.isFinite(value)) return "--";
    const sign = value > 0 ? "+" : "";
    return `${sign}${value.toFixed(2)}`;
}

// Top summary row (Today's Signals / Open Trades / Balance from the
// reference design) - reads state/demo-account data that's already being
// computed elsewhere; adds no new data sources of its own.
function renderStatStrip() {
    if (elements.statSignalsCount) {
        elements.statSignalsCount.textContent = String(state.history.length);
    }

    const acc = demo.get();

    if (elements.statOpenTrades) {
        elements.statOpenTrades.textContent = String(acc.trades.length);
    }

    if (elements.statAccountBalance) {
        elements.statAccountBalance.textContent = `$${formatCurrency(acc.balance)}`;
    }

    if (elements.statAccountBalanceSub) {
        const startingBalance = 10000;
        const pctChange = startingBalance > 0
            ? ((acc.balance - startingBalance) / startingBalance) * 100
            : 0;
        elements.statAccountBalanceSub.textContent =
            `${pctChange >= 0 ? "+" : ""}${pctChange.toFixed(2)}% since reset`;
    }
}

function renderHistory() {
    if (!state.history.length) {
        elements.historyList.innerHTML = `<div class="empty-history">No signals yet</div>`;
        return;
    }

    elements.historyList.innerHTML = state.history.map(item => `
        <div class="history-row">
            <time>${item.time.toLocaleTimeString()}</time>
            <strong data-signal="${item.type.toLowerCase()}">${item.type}</strong>
            <span>${item.confidence}%</span>
            <span>${formatPrice(item.price)}</span>
            <small>${item.action}: ${item.reason}</small>
        </div>
    `).join("");


    renderStatStrip();
}

function renderPaperAccount(markPrice) {
    const pnl = getPaperPnl(markPrice);

    elements.paperPosition.textContent = state.paper.side
        ? `${state.paper.side.toUpperCase()} ${state.paper.quantity}`
        : "Flat";
    elements.paperEntry.textContent = formatPrice(state.paper.entry);
    elements.paperPnl.textContent = formatCurrency(pnl);
    elements.paperPnl.dataset.pnl = pnl < 0 ? "loss" : pnl > 0 ? "gain" : "flat";

    if (elements.paperStop) elements.paperStop.textContent = formatPrice(state.paper.stopLoss);
    if (elements.paperTarget) elements.paperTarget.textContent = formatPrice(state.paper.takeProfit);
}

// The persisted "real" account: balance/equity/margin/win-rate driven by
// every demo trade you actually take, independent of whatever the paper
// simulator above is doing tick to tick.
function renderDemoAccount() {
    const acc = demo.get();

    renderStatStrip();

    if (elements.demoBalance) elements.demoBalance.textContent = `$${formatCurrency(acc.balance)}`;
    if (elements.demoEquity) elements.demoEquity.textContent = `$${formatCurrency(acc.equity)}`;
    if (elements.demoMarginUsed) elements.demoMarginUsed.textContent = `$${formatCurrency(acc.marginUsed)}`;
    if (elements.demoFreeMargin) elements.demoFreeMargin.textContent = `$${formatCurrency(demo.getFreeMargin())}`;
    if (elements.demoWinRate) elements.demoWinRate.textContent = `${demo.getWinRate()}%`;
    if (elements.demoTrades) elements.demoTrades.textContent = String(demo.getTotalTrades());

    if (elements.demoNetProfit) {
        const net = demo.getNetProfit();
        elements.demoNetProfit.textContent = `${net >= 0 ? "+" : ""}$${formatCurrency(net)}`;
        elements.demoNetProfit.dataset.pnl = net < 0 ? "loss" : net > 0 ? "gain" : "flat";
    }

    renderDemoLeaderboard();
    renderHistoryTable(elements.demoHistoryList);
    renderJournal(elements.journalList);
}

function renderDemoLeaderboard() {
    if (!elements.demoLeaderboardBody) return;
    const rows = getStrategyLeaderboard();
    elements.demoLeaderboardBody.innerHTML = rows.length
        ? rows.map(row => `
            <tr>
                <td>${row.strategy}</td>
                <td>${row.trades}</td>
                <td>${formatNumber(row.winRate, 1)}%</td>
                <td data-pnl="${row.totalPnl < 0 ? "loss" : row.totalPnl > 0 ? "gain" : "flat"}">${formatSigned(row.totalPnl)}</td>
                <td>${formatSigned(row.avgPnl)}</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5" class="empty-history">No closed demo trades yet</td></tr>`;
}

function getPaperPnl(markPrice) {
    if (!state.paper.side || !Number.isFinite(markPrice)) {
        return state.paper.realizedPnl;
    }

    return state.paper.realizedPnl + calculatePositionPnl(markPrice);
}

function calculatePositionPnl(markPrice) {
    if (!state.paper.side || !state.paper.entry) return 0;

    const difference = state.paper.side === "long"
        ? markPrice - state.paper.entry
        : state.paper.entry - markPrice;

    return difference * state.paper.quantity;
}

function setExecutionStatus(message) {
    elements.executionStatus.textContent = message;
}

function drawChart() {
    const candles = state.candles.slice(-80);
    const { width, height } = resizeCanvas();

    ctx.clearRect(0, 0, width, height);

    if (candles.length < 2) return;

    const closes = candles.map(candle => candle.close);
    const min = Math.min(...closes);
    const max = Math.max(...closes);
    const range = max - min || 1;
    const xStep = width / (candles.length - 1);

    ctx.lineWidth = 2;
    ctx.strokeStyle = "#56d6a7";
    ctx.beginPath();

    candles.forEach((candle, index) => {
        const x = index * xStep;
        const y = height - (((candle.close - min) / range) * (height - 28)) - 14;

        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });

    ctx.stroke();

    ctx.fillStyle = "#475569";
    ctx.font = "12px Arial";
    ctx.fillText(formatPrice(max), 8, 16);
    ctx.fillText(formatPrice(min), 8, height - 8);
}

function resizeCanvas() {
    const pixelRatio = window.devicePixelRatio || 1;
    const rect = elements.chart.getBoundingClientRect();
    const width = Math.floor(rect.width * pixelRatio);
    const height = Math.floor(rect.height * pixelRatio);

    if (elements.chart.width !== width || elements.chart.height !== height) {
        elements.chart.width = width;
        elements.chart.height = height;
    }

    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    return { width: rect.width, height: rect.height };
}

function formatPrice(value) {
    if (!Number.isFinite(value)) return "--";
    return value.toLocaleString(undefined, {
        maximumFractionDigits: value >= 100 ? 2 : 6
    });
}

function formatNumber(value, digits = 2) {
    if (!Number.isFinite(value)) return "--";
    return value.toFixed(digits);
}

function formatCurrency(value) {
    return value.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

window.addEventListener("resize", drawChart);
renderHistory();
renderTester();
renderBinaryStats();
renderDemoAccount();
init();
